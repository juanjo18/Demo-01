var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var cargaSchema = new Schema({ 
  	servicio:[{type: String, required :[true,'Es requerido']}],
    tipo: [{type: String}],
    area: [{type: String}],
},{ collection:'carga'});
 

module.exports = mongoose.model('Carga', cargaSchema);
