var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var reporteSchema = new Schema({
    // usuario: { type: Schema.Types.ObjectId, ref : 'Usuario', required:[true,'El id de user es obligatorio']},
    userID: { type: Schema.Types.ObjectId, ref : 'Usuario', required:[true,'El id de user es obligatorio']},
    matriz: [{type: Schema.Types.ObjectId, ref : 'Matriz', required:[true, 'El id matriz es obligatorio']}]

});


module.exports = mongoose.model('Reporte', reporteSchema);
