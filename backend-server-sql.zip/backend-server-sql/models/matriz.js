var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var historicoSchema = new Schema({
    oc_ant: {type: String},
    numserie_ant: {type: String},
    descrip_ant: {type:String},
    status: {type: String},
    fecha: {type: String}
});


var diasSchema = new Schema({
    year: {type: Number},
    month: {type: Number},
    days: {type: Number}
});

var mttoSchema = new Schema({
    diastotalmtto: {type: String},
    duracionmtto : {type: String},
    iniciomtto: {type: String},
    vencimtto: {type: String},
    montomtto: {type: String},
    montoanual: {type: String},  
    dias: diasSchema
});


var matrizSchema = new Schema({ 

    proveedor: {type: String}, 
    // alias_prov:{type: String},   //
    tipo: {type: String},       //
    servicio: {type: String},   //
    descripcion: {type: String},   //
    area: {type: String},           //
    oc: {type: String},             //
    anniocompra: {type: Number}, //
    cliente: {type: String},    //
    // alias_cli: {type: String},  //
    wbs: {type: String},        //
    nombre_wbs: {type: String}, //
    numserie: {type: String},   //
    moneda: {type: String},
    
    totallic: {type: Number},
    observaciones: {type: String},
    creado: {type: String},
    
    mtto: mttoSchema,
    historico: []
    
},{ collection:'matriz'});
 


module.exports = mongoose.model('Matriz', matrizSchema);
