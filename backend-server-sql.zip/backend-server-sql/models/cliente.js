const Sequelize = require('Sequelize');
const db = require('../config/database');


var Cliente = db.define('clientes', {
    id_cliente: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true},
    client_nombre: { type: Sequelize.STRING, allowNull: false},
    client_alias: { type: Sequelize.STRING, allowNull: false},
})

module.exports = Cliente;