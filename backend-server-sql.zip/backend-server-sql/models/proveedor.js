const Sequelize = require('Sequelize');
const db = require('../config/database');


var Proveedor = db.define('proveedores', {
	id_proveedor: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true},
	prov_nombre: { type: Sequelize.STRING, allowNull: false},
	prov_alias: { type: Sequelize.STRING, allowNull: false},
})

module.exports = Proveedor;