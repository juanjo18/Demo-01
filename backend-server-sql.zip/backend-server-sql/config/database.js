var Sequelize = require('sequelize');
module.exports = new Sequelize('Supplier_Management_Pro', 'sa', 'Septiembre.2019', {
  host: 'localhost',
  dialect: 'mssql'
  
});

