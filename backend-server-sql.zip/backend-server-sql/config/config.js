
module.exports.SEED = 'este-es-un-seed-dificil';

