// Required import librarys
var express = require('express');
var bodyParser = require('body-parser');
var xlsxj = require("xlsx-to-json");
var path  = require("path");

var fs = require('fs');
//var sql = require('mysql');
var mysql = require('mssql');

// Inicializar variable
var app = express();

//CORS
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    res.header("Access-Control-Allow-Methods", "POST, GET, PUT, DELETE, OPTIONS");
    next();
 });




//Bodyparser
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

//Importar rutas
var appRoutes = require('./routes/app');
var usuarioRoutes = require('./routes/usuario');
var proveedorRoutes = require('./routes/proveedor');
var clientesRoutes = require('./routes/cliente');
var notificacionRoutes = require('./routes/notificacion');
var reporteRoutes = require('./routes/reporte');
var busquedaRoutes = require('./routes/busqueda');
var loginRoutes = require('./routes/login');
var uploadFiles = require('./routes/upload');
var imagenesRoutes = require('./routes/imagenes');
var matrizRoutes = require('./routes/matriz');
var cargaRoutes = require('./routes/carga');


//Database conexion 

const db = require('./config/database');
db.authenticate()
  .then(() => {
    console.log('Conectado');
    app.listen(3000,()=>{
    console.log('Express puerto 3000: \x1b[32m%s\x1b[0m',' online');
    });
})
  .catch(err => {
    console.log('No se conecto');
})





//Rutas -> Middleware
app.use('/usuario', usuarioRoutes);
app.use('/cliente', clientesRoutes);
app.use('/proveedor', proveedorRoutes);
app.use('/login', loginRoutes);
app.use('/busqueda', busquedaRoutes);
app.use('/notificacion',notificacionRoutes);
app.use('/reporte', reporteRoutes);
app.use('/matriz', matrizRoutes);
app.use('/upload', uploadFiles);
app.use('/img', imagenesRoutes);  
app.use('/carga', cargaRoutes);

app.use('/', appRoutes);

//Escuchando en el puerto
