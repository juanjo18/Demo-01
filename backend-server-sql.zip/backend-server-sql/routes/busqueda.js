// Required import librarys
// var mdAutenticacion = require('../middlewares/autenticacion');
var express = require('express');
var app = express();

var Proveedor = require('../models/proveedor');
var Cliente = require('../models/cliente');
var Usuario = require('../models/usuario');
var Matriz = require('../models/matriz');

// ============================
// 	Busqueda general // Request, Response, Next (Middleware)
// ============================

app.get('/all/:busqueda', (req, res, next) => {

    var busqueda =  req.params.busqueda;
    var regex = new RegExp( busqueda, 'i' );

    Promise.all([
        buscarProveedores(busqueda, regex),
        buscarClientes(busqueda, regex),
        buscarUsuarios(busqueda, regex),
        buscarDatos(busqueda, regex)

        ]).then( respuestas =>{
            
            res.status(200).json({
                ok : true,
                proveedores: respuestas[0],
                clientes: respuestas[1],
                usuarios: respuestas[2],
                matriz : respuestas[3]
                });
        })

});

function buscarDatos(busqueda, regex){
 return new Promise(( resolve, reject ) => {

    Matriz.find({})
        .or([
            { 'oc': regex}, 
            { 'proveedor' : regex }, 
            { 'servicio': regex },
            { 'cliente':regex },
            { 'area':regex }
            ])

            // .populate('')

            .exec((err, matriz) =>{
                if(err){
                    reject('Error al cargar datos')
                }else{
                    resolve(matriz);
                }

            })
    })
}

function buscarProveedores(busqueda, regex){
    return new Promise((resolve, reject)=>{
        Proveedor.findOne({
            attributes: ['prov_nombre', 'prov_alias'],
            where:{
                prov_nombre: regex
            }
        })
        .then(proveedores =>{
            resolve(proveedores);
        })
        .catch(err =>{
            reject('Error al cargar proveedores', err);
        })

    });
}

function buscarClientes(busqueda, regex){
    return new Promise((resolve, reject)=>{  
        Cliente.find({nombre: regex})
                .populate('usuario', 'nombre email')
                .populate('proveedor')
                .exec( (err, clientes) => {

                    if(err){
                        reject('Error al cargar clientes', err);
                    }

                    else{
                        resolve(clientes);
                    }
                });
            
        });
}

function buscarUsuarios(busqueda, regex){
    return new Promise((resolve, reject)=>{  
       Usuario.find({}, 'nombre email role')
               .or([{ 'nombre': regex}, {'email': regex }])
                .exec( (err, usuario) =>{   
                    if(err){
                        reject(' Error al buscar usuario ', err);
                    }
                    else{
                        resolve(usuario);
                    }
                })    
    });

}


// ===================================
// 	Busqueda por coleccion especifica
// ===================================
app.get('/coleccion/:tabla/:busqueda', (req, res, next) => {

    var tabla = req.params.tabla;
    var busqueda =  req.params.busqueda;
    var regex = new RegExp( busqueda, 'i' );

    switch(tabla){

        case 'usuarios': 
            promesa = buscarUsuarios(busqueda,regex);
        break;
        
        case 'proveedores':
            promesa = buscarProveedores(busqueda, regex);
        break;

        case 'clientes':
            promesa = buscarClientes(busqueda, regex);
        break;

        case 'matriz':
            promesa = buscarDatos(busqueda, regex);
        break;

        default:
            return res.status(400).json({
                ok: false,
                mensaje: 'Solo busqueda por usuario, proveedor, cliente, matriz',
                error:{ mensaje: 'Tabla / Collection no encontrado', err}
            })
        
    }

     promesa.then(data =>{
        res.status(200).json({
            ok:true,
            [tabla]:data
        })
     })
    
});


module.exports = app;