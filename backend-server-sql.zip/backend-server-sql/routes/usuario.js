// Required import librarys
var express = require('express');
const db = require('../config/database');
var bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
const Usuario = require('../models/Usuario');
var mdAutenticacion = require('../middlewares/autenticacion');


var app = express();

// ==========================================
//  Obtener usuarios
// ==========================================
app.get('/', (req, res, next) => {

    var desde = req.query.desde || 0;//Var de paginacion
    desde = Number(desde); //Var de paginacion

    Usuario.findAndCountAll({
        // Para lo de paginacion
        offset:desde , limit: 5
    })
    .then(usuarios => {
        res.status(200).json({
            total: usuarios.count,
            usuarios: usuarios.rows
        })
    })
    .catch(err => {
        return res.status(500).json({
            ok: 'false',
            mensaje: 'Error al obtener los usuarios',
            errors: err
        })
    })
    
});


// ==========================================
//  Crear usuarios
// ==========================================
app.post('/', (req, res, next) =>{

	var body = req.body;

	Usuario.create({
		nombre: body.nombre,
		correo: body.correo,
		password: bcrypt.hashSync(body.password, 10),
		permiso_rol: 'SMD_ROLE'
	})
	.then(usuario =>{
		res.status(200).json({
			ok: 'true',
			mensaje: 'Usuario creado bien'
		})
	})
	.catch( err => {
        return res.status(500).json({
            ok: 'false',
            mensaje: 'Error al crear el usuario',
            errors: err
        })
    })
});


app.put('/:id', (req, res) =>{
    var id = req.params.id;
    var body = req.body;

    Usuario.update({
        nombre: body.nombre,
    },
    {
        where: {
            id_usuario: id
        },
        returning: true, // needed for affectedRows to be populated
        plain: true // 
    }
    )
    .then(resultado => {
        if(resultado){
            res.status(200).json({
                // ok: 'true',
                // mensaje: 'Usuario actualizado',
                estado: resultado
                // otro: affectedRows
            })
        }
        else{
            return res.status(400).json({
                ok: 'false',
                mensaje: 'No se encuetra ese cliente'
            })
        }
    })
    .catch(err => {
        return res.status(500).json({
            ok: 'false',
            mensaje: 'Error al actualizar el usuario'
        })
    })
});


app.delete('/:id', (req, res) =>{
    var id = req.params.id;

    Usuario.destroy({
        where:{
            id_usuario: id
        }
    })
    .then(resultado => {
        return res.status(200).json({
            ok: 'true',
            mensaje: 'Si se elimino'
        })
    })
    .catch(err => {
        return res.status(500).json({
            ok: 'false',
            mensaje: 'Error al eliminar el cliente'
        })
    })
});

module.exports = app;
