// Required import librarys
var express = require('express');
// var mdAutenticacion = require('../middlewares/autenticacion');
var app = express();

var Matriz = require('../models/matriz');

// ==========================================
//  Obtener todos los datos
// ==========================================
app.get('/', (req, res, next) => {
    var desde = req.query.desde || 0;//Var de paginacion
    desde = Number(desde); //Var de paginacion

  	Matriz.find({})
	// .populate('proveedor')
    .skip(desde)    //Paginacion
    .limit(6)       //Paginacion
	.exec(
	  	(err, matriz) => {

	  		if (err) {
	  			return res.status(500).json({
	  				ok:false,
	  				mensaje:"Error cargar matriz",
	  				errors: err
	  			})
	  		}
	  		Matriz.countDocuments({}, (err, conteo) =>{
	  			res.status(200).json({
	  				// ok:true,
	  				total: conteo,
	  				matriz: matriz
	  			})
	  		})
	  	}
	)

})

// ==========================================
//  Obtener ID del dato
// ==========================================
app.get('/:id',(req,res) => {
	var id = req.params.id;

    if (id === 'nuevo') {
     return;
    }

    if( id != 'nuevo') {
        Matriz.findById(id)
        .exec(
        (err, matriz) => {
            if (err) {
                return res.status(500).json({
                    ok: false,
                    mensaje: 'Error al buscar datos',
                    errors: err
                });
            }

            if (!matriz) {
                return res.status(400).json({
                    ok: false,
                    mensaje: 'El dato con el id'+ id + 'no existe',
                    errors: { message:'No existe un dato con ese ID' }
                });
            }

            res.status(200).json({
                // ok: true,
               matriz: matriz
            });
        })

    }

})

// ==========================================
//  Crear dato
// ==========================================
app.post('/', (req, res) =>{
    var body = req.body;
    //Objeto -> Inicializar
    var matriz =  new Matriz({
        proveedor: body.proveedor,
        cliente: body.cliente,
        tipo: body.tipo,
        area: body.area,
        oc: body.oc,
        servicio:body.servicio,
        numserie: body.numserie,
        moneda : body.moneda,
        tipopago : body.tipopago,
        descripcion: body.descripcion,
        wbs: body.wbs,
        nombre_wbs: body.nombre_wbs,
        creado: body.creado,
        moneda: body.moneda,
        anniocompra: body.anniocompra,
        observaciones: body.observaciones,


        historico:[{
                oc_ant:'',
                numserie_ant: '',
                descrip_ant: '',
                status: ''
        }],

        mtto: {
                diastotalmtto: body.mtto.diastotalmtto,
                montomtto: body.mtto.montomtto,
                montoanual: body.mtto.montoanual,
                duracionmtto: body.mtto.duracionmtto,
                iniciomtto: body.mtto.iniciomtto,
                vencimtto: body.mtto.vencimtto,
                dias: {
                    year: body.mtto.dias.year,
                    month: body.mtto.dias.month,
                    days: body.mtto.dias.days
                }
        }

    });


    matriz.save((err, matrizGuardado)=>{
        if(err){
            return res.status(400).json({
                ok:false,
                mensaje : "Error al crear dato",
                errors : err
            });
        }

        res.status(200).json({
            ok: true,
            matriz : matrizGuardado
        });

    });

})

// ==========================================
//  Actualizar Dato de la Matriz
// ==========================================
app.put('/:id',(req,res) => {
    var id =  req.params.id;
    var body = req.body;

    Matriz.findById(id,(err , matriz)=>{

        if (err) {
            return res.status(500).json({
                ok: false,
                mensaje: 'Error al buscar matriz',
                errors: err
            });
        }

        if(!matriz){
            return res.status(400).json({
                ok: false,
                mensaje: 'El campo con el id '+ id +'no existe',
                errors: {menssage : "No existe un dato con ese ID"}
            });
        }


        matriz.oc = body.oc;
        matriz.numserie = body.numserie;
        matriz.descripcion = body.descripcion;
        // matriz.tipo = body.tipo;
        // matriz.area = body.area;
        // matriz.servicio = body.servicio;
        // matriz.wbs = body.wbs;
        // matriz.nombre_wbs = body.nombre_wbs;

        matriz.mtto.dias.year = body.mtto.dias.year;
        matriz.mtto.dias.month = body.mtto.dias.month;
        matriz.mtto.dias.days = body.mtto.dias.days;

        matriz.mtto.diastotalmtto = body.mtto.diastotalmtto
        matriz.mtto.iniciomtto = body.mtto.iniciomtto;
        matriz.mtto.vencimtto = body.mtto.vencimtto;
        matriz.mtto.montoanual = body.mtto.montoanual;
        matriz.mtto.montomtto = body.mtto.montomtto;

        // matriz.historico.oc_ant = body.historico.oc_ant;
        // matriz.historico.status = body.historico.status;

        matriz.historico = [{
            oc_ant: body.historico[0].oc_ant,
            numserie_ant: body.historico[0].numserie_ant,
            descrip_ant: body.historico[0].descrip_ant,
            status: body.historico[0].status,
            fecha: body.historico[0].creado
        }];

        console.log(matriz);

        matriz.save((err, matrizGuardado)=>{
            if(err){
                return res.status(400).json({
                    ok: false,
                    mensaje: 'Error al actualizar el dato',
                    errors: err
                });
            }

            res.status(200).json({
                 ok: true,
                 matriz: matrizGuardado
            });

        })

    });
})

// ==========================================
//  Eliminar dato de la matriz
// ==========================================
app.delete('/:id', (req,res)=>{
    var id = req.params.id;

    Matriz.findByIdAndRemove(id,(err, matrizBorrado)=>{

        if (err) {
            return res.status(500).json({
                ok: false,
                mensaje: 'Error al borrar dato de la matriz',
                errors: err
            });
        }

        if(!matrizBorrado){
            return res.status(400).json({
                ok: false,
                mensaje: 'No existe dato de matriz con el id '+ id ,
                errors: {menssage : "No existe un dato con ese ID"}
            });
        }

        res.status(200).json({
            ok: true,
            mensaje: 'Dato eliminado exitosamente',
            matriz: matrizBorrado
       });

    });

});



module.exports = app;
