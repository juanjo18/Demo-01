//Required import librarys
var express = require('express');
var app = express();

var mdAutenticacion = require('../middlewares/autenticacion');

var Matriz = require('../models/matriz');
var tempMatriz = require('../models/matriz');
var Usuario = require('../models/usuario');

// var tempMatriz = [];

// ==========================================
// Obtener reporte por ID
// ==========================================
app.get('/:id', (req,res,next) => {
   var id = req.params.id;

   Usuario.findById(id, (err,usuario) => {
        if (err){
          return res.status(500).json({
                ok: false,
                mensaje: 'Error al buscar usuario',
                errors: err
            });
        }

        if(!usuario){
            return res.status(400).json({
                ok: false,
                mensaje: 'El usuario con el id '+ id +'no existe',
                errors: {menssage : "No existe un user con ese ID"}
            });
        }

      var reporte = usuario.reporte.length;
      for(var i = 0; i< reporte; i++){
         // console.log(usuario.reporte[i])
        Matriz.findById(usuario.reporte[i])
         .exec(
          (err, matriz) => {
            if (err) {
                return res.status(500).json({
                    ok: false,
                    mensaje: 'Error al buscar datos',
                    errors: err
                });
            }

            if (!matriz) {
                return res.status(400).json({
                    ok: false,
                    mensaje: 'El dato con el id'+ id + 'no existe',
                    errors: { message:'No existe un dato con ese ID' }
                });
            }
         
         })

      }
      
     console.log(tempMatriz);


      }) // FinUserId

});

// ==========================================
// Guardar reporte por ID de usuario
// ==========================================
app.post('/:id', (req,res) =>{
   var body = req.body;

   Usuario.findOneAndUpdate(
      { _id: req.params.id },
      { $push:
          {  reporte: body }
      },
      { new:true }

   )
   .exec((err,usuario)=>{
      if(err){
        return res.status(500).json({
          ok:false,
          mensaje: 'Error al insertar reporte',
          errors: err
        })
      }

      usuario.save((err,usuarioGuardado)=>{
        if(err){
            return res.status(400).json({
              ok:false,
              mensaje: 'Hubo error',
              errors: err
             })
          }
          res.send(usuario);
      })

   })
   

});

module.exports = app;
