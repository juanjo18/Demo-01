// Required import librarys
var express = require('express');
var bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
var SEED = require('../config/config').SEED;

var app = express();
var menu = [];
var Usuario = require('../models/usuario');

app.post('/', (req, res)=>{

  var body = req.body;


  Usuario.findOne({
    attributes: ['id_usuario', 'nombre', 'correo', 'password', 'permiso_rol'],
    where:{
        correo: body.correo
    }
  })
  .then(usuario => {

    // Se verifica que el correo sea valido
    if(usuario){
        if(!bcrypt.compareSync(body.password, usuario.dataValues.password)){
            return res.status(400).json({
                ok: 'false',
                mensaje: 'Error, contraseña incorrecta'
            })
        }
        else{
            var token = jwt.sign( {usuario: usuario.dataValues.id_usuario}, SEED ,{ expiresIn:14400 })

            res.status(200).json({
                usuario: usuario,
                id: usuario.dataValues.id_usuario,
                token: token,
                menu: obtenerMenu(usuario.dataValues.permiso_rol)

            })
        }
    }
    else{
       return res.status(400).json({
            ok: 'false',
            mensaje: 'El correo no existe'
        })
    }
  })
  .catch( err => console.log(err))

});


function obtenerMenu(ROLE){
    
 if(ROLE === 'ADMIN_ROLE'){
    var menu = [
        {
          titulo : 'Mantenimiento',
          icono :'fa fa-users',
          submenu : [
            { titulo: 'Usuarios',icono:'fa fa-edit', url: '/usuarios' },
            { titulo : 'Proveedores',icono:'fa fa-edit',url: '/proveedores' },
            { titulo : 'Clientes',icono:'fa fa-edit',url: '/clientes' }
              ]
        },  
        {
           titulo : 'Matriz',
           icono : 'fa fa-upload',
           submenu : [
             { titulo :' Importar Matriz' , icono : 'fa fa-file-excel-o' , url:'/matriz' }
           ]
        },
        {
           titulo : 'Graficas', 
           icono :'fa fa-bar-chart-o', 
           submenu : [
             { titulo : 'Ver', icono:'fa fa-eye', url: '/graficas' }
           ]
        }
    ];
  return menu;  
 }
 else{
    var menu = [
        {
           titulo : 'Reporte', 
           icono :'fa  fa-file-text-o', 
           submenu : [
             { titulo : 'Descargar', icono:'fa fa-cloud-download', url: '/reporte' }
           ]
        },

        {
           titulo : 'Acerca', 
           icono :'fa  fa-question-circle', 
           submenu : [
             { titulo : 'Progreso',icono:'fa fa-user-o',url: '/dashboard' }
           ]
        }
    ];
 return menu;
 }
}

module.exports = app;