// Required import librarys
var express = require('express');
var app = express();

var Carga = require('../models/carga');

// Obtener datos de carga
app.get('/', (req, res, next) => {
    res.status(200).json({
        mensaje:'Peticion realizada',
        ok : true
    });
});

// Crear un servicio, tipo, area
app.post('/',(req, res) =>{
	var body = req.body;

	var carga = new Carga({
		servicio: body.servicio,
		tipo: body.tipo,
		area: body.area
	});

	carga.save((err, cargaGuardado) => {
		if(err){
			return res.status(400).json({
				ok: false,
				mensaje: "Error al cargar",
				errors: err
			})
		}
		res.status(200).json({
			ok: true,
			carga: cargaGuardado
		})
	})

});



module.exports = app;