// Required import librarys
var express = require('express');
// var mdAutenticacion = require('../middlewares/autenticacion');
var app = express();

var Usuario = require('../models/usuario');
var Matriz = require('../models/matriz');
// ==========================================
//  Obtener todas las notificaciones
// ==========================================
app.get('/', (req, res, next) => {
    var desde = req.query.desde || 0;//Var de paginacion
    desde = Number(desde); //Var de paginacion

  	Matriz.find({})
	// .populate('proveedor')
    .skip(desde)    //Paginacion
    .limit(6)       //Paginacion
	.exec(
	  	(err, matriz) => {

	  		if (err) {
	  			return res.status(500).json({
	  				ok:false,
	  				mensaje:"Error cargando notificaciones",
	  				errors: err
	  			})
	  		}
	  		Matriz.countDocuments({}, (err, conteo) =>{
	  			res.status(200).json({
	  				// ok:true,
	  				total: conteo,
	  				matriz: matriz
	  			})
	  		})
	  	}
	)

})

// ==========================================
//  Obtener ID de la notificacion
// ==========================================
app.get('/:id',(req,res) => {
	var id = req.params.id;
    
    if (id == 'nuevo') {
        return;
    }

    else{ 
        Matriz.findById(id)
    // .populate('usuario', 'nombre alias descripcion')
        .exec(
        (err, matriz) => {
            if (err) {
                return res.status(500).json({
                    ok: false,
                    mensaje: 'Error al buscar datos',
                    errors: err
                });
            }

            if (!matriz) {
                return res.status(400).json({
                    ok: false,
                    mensaje: 'El dato con el id'+ id + 'no existe',
                    errors: { message:'No existe un dato con ese ID' }
                });
            }        

            res.status(200).json({
                // ok: true,
               matriz: matriz
            });
        })

    }
    
})


// ==========================================
//  Agregar historico
// ==========================================
app.post('/:id', (req,res,next) =>{
    var body = req.body;
    // Version 1 Funciona
    // var id =  req.params.id;
    // Matriz.findOneAndUpdate(
    //     { _id: req.params.id },
    //     { $push:{ historico:{ oc_ant:'Prueba2', status:'Renov', numserie_ant:'123123' } } },
    //     { new: true }
    // )
    // .exec()
    //     .then(function(matriz){
    
    //         res.send(matriz);
    //     })

    // Version 2 Funciona Modificada
    Matriz.findOneAndUpdate(
        { _id: req.params.id },
        { $push:{ 
                historico:{ 
                    oc_ant: body.historico[0].oc_ant, 
                    status: body.historico[0].status,
                    descrip_ant: body.historico[0].descrip_ant, 
                    numserie_ant: body.historico[0].numserie_ant, 
                    fecha: body.historico[0].fecha
                    } 
                } 
        },
        { new: true }
    )
    .exec((err, matriz) => {
        if(err){
            return res.status(500).json({
                ok: false,
                mensaje: 'Error al insertar historico',
                errors: err
            });   
        }

        matriz.oc = body.oc;
        matriz.mtto.diastotalmtto = body.mtto.diastotalmtto;

        matriz.save((err, matrizGuardado)=>{
            if(err){
                return res.status(400).json({
                    ok:false,
                    mensaje: 'Hubo error',
                    errors: err
                })
            }
            res.send(matriz);
        })
       
    })
 
});


module.exports = app;