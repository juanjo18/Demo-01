// Required import librarys
var express = require('express');
var request = require('request');   //Request

var fileUpload = require('express-fileupload');
var xlsxj = require('xlsx-to-json');

const fs = require('fs');
// const fs = require('file-system');

var Matriz = require('../models/matriz');
var Usuario = require('../models/usuario');

var app = express();

// default options
app.use(fileUpload());

//Lectura de archivos excel 
app.post('/', (req, res) => {    
    var archivo = req.files.excel;
    var nombreCortado = archivo.name.split('.');
    var extensionArchivo = nombreCortado[nombreCortado.length - 1]; //EXCEL
   
    //Solo extensiones aceptadas
    var extensionValidas = ['xlsx'];

    if (extensionValidas.indexOf(extensionArchivo) < 0) {
        return res.status(400).json({
            ok: false,
            mensaje: 'Extension de archivo no soportada',
            errors: { message: 'Las extensiones validas son ' + extensionValidas.join(', ') }
        });
    }

    var fecha  = new Date();    
    fecha = (fecha.getDate() + "-" + (fecha.getMonth()+ 1) + "-" + fecha.getFullYear());

    // Nombre de archivo personalizado
    var nombreArchivo = `${fecha}.${extensionArchivo}`;
    var nombreJson = `${fecha}.json`;


    //Mover el archivo del temporal a un path -> JSON
    var path = `./uploads/matriz/excel/${nombreArchivo}`;
    
    archivo.mv(path, err => {
        if (err) {
            return res.status(400).json({
                ok: false,
                mensaje: 'Error al mover archivo',
                errors: err
            });
        }
        if (!req.files) {
            return res.status(400).json({
                ok: false,
                mensaje: 'No ha seleccionado nada',
                errors: { message: 'Debe de seleccionar un excel' }});
            }
    })

    setTimeout(() => crearJson(nombreArchivo, nombreJson), 1000);

    res.status(200).json({
    ok: true
    });

});

app.get('/', (req, res) => {  

    var fecha  = new Date();    
    fecha = (fecha.getDate() + "-" + (fecha.getMonth()+ 1) + "-" + fecha.getFullYear());
    fecha+='.json';

    // var Matriz = mongoose.model('Matriz', matrizSchema, 'matriz');
    let rawdata = fs.readFileSync("./uploads/matriz/json/"+fecha);
    matrizA = JSON.parse(rawdata);
    var matrizB;
    // console.log(matrizA.length);

    for(var i=0; i < matrizA.length; i++){  
        var prov = matrizA[i].PROVEEDOR; 
        var alias_p = matrizA[i].ALIAS_VENDOR;
        var servicio = matrizA[i].SERVICIO;
        var tipo = matrizA[i].TIPO;
        var orden = matrizA[i].OC;
        var descrip = matrizA[i].DESCRIPCION;
        var cliente = matrizA[i].CLIENTE;
        var alias_c = matrizA[i].ALIAS_CLIENTE;
        var wbs = matrizA[i].WBS;
        var nombre_wbs = matrizA[i].NOMBRE_WBS;
        var area = matrizA[i].AREA;

        var matriz1 =  new Matriz({ 
            proveedor: prov,
            alias_prov: alias_p,
            servicio: servicio,
            tipo: tipo,
            oc: orden,
            descripcion: descrip,
            cliente: cliente,
            alias_cli: alias_c,
            wbs: wbs,
            nombre_wbs: nombre_wbs,
            area: area, 
        });

    matriz1.save(function(err, result){
        if (err){
            console.log("Error",err);     
        }
         // console.log(matriz1);                  
        })

    } //CicloFor
 
    res.status(200).json({
     ok: true,
     mensaje: 'Sucess'
    });

});

app.put('/:tipo/:id',(req, res, next) => {

    var tipo = req.params.tipo;
    var id = req.params.id;

    if(!req.files){
        return res.status(400).json({
            ok: false,
            mensaje: 'No ha seleccionado nada',
            errors: {message:'Debe de seleccionar una imagen'}
        });
    }

    // Obtener nombre del archivo
    var archivo = req.files.imagen;
    var nombreCortado = archivo.name.split('.');
    var extensionArchivo = nombreCortado[nombreCortado.length - 1]; 
   
    //Solo extensiones aceptadas
    var extensionValidas = ['png','jpeg','gif','jpg'];

    if (extensionValidas.indexOf(extensionArchivo) < 0) {
        return res.status(400).json({
            ok: false,
            mensaje: 'Extension de archivo no soportada',
            errors: { message: 'Las extensiones validas son ' + extensionValidas.join(', ') }
        });
    }

    var tiposValidos = ['usuarios','clientes','proveedores'];

    if(tiposValidos.indexOf( tipo ) < 0 ){
        return res.status(400).json({
            ok: false,
            mensaje: 'Tipo de coleccion no valido',
            errors: { message: 'Las colecciones validas son ' + tiposValidos.join(', ') }
        });
    }


    // Nombre de archivo personalizado
    var nombreArchivo = `${ id }-${ new Date().getMilliseconds() }.${ extensionArchivo }`;

    //Mover el archivo del temporal a un path
    var path = `./uploads/${tipo}/${nombreArchivo}`;

    archivo.mv(path, err => {

        if (err) {
            return res.status(400).json({
                ok: false,
                mensaje: 'Error al mover archivo',
                errors: err
            });
        }

        subirPorTipo(tipo, id, nombreArchivo, res);

    })
})


function crearJson(nombre,ext){    
    xlsxj({
        input: "./uploads/matriz/excel/"+nombre,
        output: "./uploads/matriz/json/"+ext
    }, 
    function (err, result) {
        if (err) {
            console.error(err);
        }
        console.log("Success");
    });

}

function subirPorTipo(tipo, id, nombreArchivo, res){

 if(tipo === 'usuarios')
 {
    Usuario.update({
        img_perfil: nombreArchivo
    },
        where:
        {
            id_usuario: id
        }
    )
    .then(resultado =>{
        if(resultado){
            res.status(200).json({
                ok: 'true',
                mensaje: 'imagen actualizada',
            })
        }
        else{
            return res.status(400).json({
                ok: 'false',
                mensaje: 'No se encuetra ese cliente'
            })
        }
    })
    .catch(err =>{
        return res.status(500).json({
            ok: 'false',
            mensaje: 'Error al actualizar la imagen'
        })
    })

 //    Usuario.findById(id, (err, usuario) =>{
 //        if (err){
 //            return res.status(500).json({
 //            ok: false,
 //            mensaje: 'Error al buscar usuario',
 //            errors: err
 //            });
 //        }
 //        var pathViejo = './uploads/usuarios/' + usuario.img;
 //            //Si existe, elimina la imagen anterior
 //            if(fs.existsSync(pathViejo)){
 //                fs.unlinkSync(pathViejo);
 //            }

 //            usuario.img = nombreArchivo;     
 //            usuario.save((err, usuarioActualizado) => {
 //                return res.status(200).json({
 //                    ok:true,
 //                    mensaje: 'Imagen de usuario actualizado',
 //                    usuario : usuarioActualizado
 //                })
            
 //            })

 //        })

 }

}

module.exports = app;