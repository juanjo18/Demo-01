// Required import librarys
var express = require('express');

var mdAutenticacion = require('../middlewares/autenticacion');

var app = express();
var fecha = new Date();
var Cliente = require('../models/cliente');

// Rutas
// ==========================================
//  Obtener todos clientes
// ==========================================
app.get('/', (req, res, next) => {
    var desde = req.query.desde || 0;//Var de paginacion
    desde = Number(desde); //Var de paginacion

    Cliente.findAndCountAll({
        // Para lo de paginacion
        offset:desde , limit: 10
    })
    .then(clientes => {
        res.status(200).json({
            total: clientes.count,
            clientes: clientes.rows
        })
    })
    .catch(err => {
        return res.status(500).json({
            ok: 'false',
            mensaje: 'Error al obtener los clientes',
            errors: err
        })
    })
});

// ==========================================
//  Actualizar clientes
// ==========================================
// AGREGAR EL TOKEN DE VERIFICACION mdAutenticacion.verificaToken
app.put('/:id',  (req,res)=>{
    var id =  req.params.id;
    var body = req.body;

    Cliente.update(
        { client_alias: body.client_alias,
          updatedAt: fecha},
        {
        where:{ 
            id_cliente: id
        }
        }
    )
    .then(resultado => {

        if(resultado){
            res.status(200).json({
                ok: 'true',
                mensaje: 'Cliente actualizado'
            })
        }
        else{
            return res.status(400).json({
                ok: 'false',
                mensaje: 'No es encuentra ese cliente'
            })
        }
    })
    .catch(err =>{
        return res.status(500).json({
            ok: 'false',
            mensaje: 'Error al actualizaar el cliente'
        })
    })

    

}); //Cierre del PUT


// ==========================================
//  Crear cliente
// ==========================================
// AGREGAR EL TOKEN DE VERIFICACION mdAutenticacion.verificaToken
app.post('/', (req, res)=>{

    var body = req.body;
    //Objeto -> Inicializar
    
    Cliente.create({
       client_nombre: body.client_nombre,
       client_alias: body.client_alias,
        createdAt: fecha,
        updatedAt: fecha
    })
    .then(cliente =>{
        res.status(200).json({
            ok:'true',
            mensaje: 'Cliente creado'
        })
    })
    .catch(err =>{
        return res.status(400).json({
            ok: 'false',
            mensaje: 'Error al crear el cliente',
            errors: err
        })
    })
    

});//Cierre del post


// ==========================================
//  Borrar cliente por ID
// ==========================================

app.delete('/:id',  (req,res)=>{
    var id = req.params.id;
    
    Cliente.destroy({
        where:{
            id_cliente: id
        }
    })
    .then(resultado => {
        res.status(200).json({
            ok: 'true',
            mensaje: 'Si se elimino'
        })
    })
    .catch(err =>{
        return res.status(500).json({
            ok: 'false',
            mensaje: 'Error al eliminar el cliente'
        })
    })

});


module.exports = app;