// Required import librarys
var express = require('express');
var mdAutenticacion = require('../middlewares/autenticacion');
var app = express();

var Proveedor = require('../models/proveedor');
var fecha = new Date();

// Rutas
// ==========================================
//  Obtener todos proveedores
// ==========================================
app.get('/', (req, res, next) => {

    var desde = req.query.desde || 0;//Var de paginacion
    desde = Number(desde); //Var de paginacion

    Proveedor.findAndCountAll({
        // Para lo de paginacion
        offset:desde , limit: 10
    })
    .then(proveedores => {
        res.status(200).json({
            total: proveedores.count,
            proveedores: proveedores.rows
        })
    })
    .catch(err => {
        return res.status(500).json({
            ok: 'false',
            mensaje: 'Error al obtener los proveedores',
            errors: err
        })
    })

});

// ==========================================
//  Obtener proveedor por ID
// ==========================================
app.get('/:id', (req, res)=>{

    var id = req.params.id;

    Proveedor.findOne({
        attributes: ['prov_nombre', 'prov_alias'],
        where:{
            id_proveedor: id
        }
    })
    .then(proveedor => {
        if(proveedor){
            res.status(200).json({
                ok: 'true',
                proveedor: proveedor
            });
        }
        else{
            return res.status(400).json({
                ok: 'false',
                mensaje: 'No exite ese proveedor'
            });
        }
    })
    .catch(err =>{
        return re.status(500).json({
            ok: 'false',
            mensaje: 'Error al buscar el proveedor'
        });
    })

});

// ==========================================
//  Actualizar proveedores
// ==========================================
// AGREGAR EL TOKEN DE VERIFICACION mdAutenticacion.verificaToken
app.put('/:id',  (req,res)=>{
    var id =  req.params.id;
    var body = req.body;

    Proveedor.update(
        { prov_alias: body.prov_alias,
          updatedAt: fecha},
        {where:{ id_proveedor: id}}
    )
    .then(resultado => {

        if(resultado){
            res.status(200).json({
                ok: 'true',
                mensaje: 'Proveedor actualizado'
            })
        }
        else{
            return res.status(400).json({
                ok: 'false',
                mensaje: 'No es encuentra ese proveedor'
            })
        }
    })
    .catch(err =>{
        return res.status(500).json({
            ok: 'false',
            mensaje: 'Error al actualizaar el proveedor'
        })
    })


}); //Cierre del PUT


// ==========================================
//  Crear proveedor
// ==========================================

// AGREGAR EL TOKEN DE VERIFICACION mdAutenticacion.verificaToken
app.post('/',  (req, res, next)=>{
    var body = req.body;
    //Objeto -> Inicializar

    Proveedor.create({
        prov_nombre: body.prov_nombre,
        prov_alias: body.prov_alias,
        createdAt: fecha,
        updatedAt: fecha
    })
    .then(proveedor =>{
        res.status(200).json({
            ok:'true',
            mensaje: 'Proveedor creado'
        })
    })
    .catch(err =>{
        return res.status(400).json({
            ok: 'false',
            mensaje: 'Error al crear el proveedor',
            errors: err
        })
    })

});//Cierre del post


// ==========================================
//  Borrar proveedor por ID
// ==========================================
// AGREGAR EL TOKEN DE VERIFICACION mdAutenticacion.verificaToken

app.delete('/:id', (req,res)=>{
    var id = req.params.id;

    Proveedor.destroy({
        where:{
            id_proveedor: id
        }
    })
    .then(resultado => {
        res.status(200).json({
            ok: 'true',
            mensaje: 'Si se elimino'
        })
    })
    .catch(err =>{
        return res.status(500).json({
            ok: 'false',
            mensaje: 'Error al eliminar el proveedor'
        })
    })

});


module.exports = app;
